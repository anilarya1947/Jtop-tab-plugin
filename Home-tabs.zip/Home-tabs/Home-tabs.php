<?php
/**
 * Plugin Name: Home page Tabs
 * Plugin URI: 
 * Description: This plugin is for home page tabs shortcode
 * Version: 1.0
 * Author: Prodigy-arya
 * Author URI: 
 */
add_action('init', 'register_script');
function register_script() {
    wp_register_script( 'custom_jquery', plugins_url('bootstrap.min.js', __FILE__), array('jquery'), '2.5.1' );

    wp_register_style( 'new_style', plugins_url('tab.css', __FILE__), false, '1.0.0', 'all');
	wp_register_style( 'new_style_boot', plugins_url('bootstrap.min.css', __FILE__), false, '1.0.0', 'all');
}

// use the registered jquery and style above
add_action('wp_enqueue_scripts', 'enqueue_style');

function enqueue_style(){
   wp_enqueue_script('custom_jquery');

   wp_enqueue_style( 'new_style' );
   wp_enqueue_style( 'new_style_boot' );
}
 
function tabs_shortcode_genrate(){
	
$return_string = '<section id="tabs"><div class="container"><div class="row"><div class="col-xs-12"><nav><div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">';
		$terms = get_terms( array(  'taxonomy' => 'menu_categories','hide_empty' => true,) );
	$j=1;
	foreach ( $terms as $term ){
		 if($j==1)
{$classj= "active";}
else{
$classj= "";	
	
} 
		 
	 $return_string .= '<a class="nav-item nav-link ' . $classj . '" id="nav-' .  $term->slug . '-tab" data-toggle="tab" href="#nav-' .  $term->slug . '" role="tab" aria-controls="nav- ' . $term->slug . '" aria-selected="true"> ' . $term->name . '</a>';
	$j++;}
$return_string .= '</div></nav><div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">';
      $terms = get_terms( array(
    'taxonomy' => 'menu_categories',
    'hide_empty' => true,
) );
$i=1;
foreach ( $terms as $term ){;

if($i==1)
{$classs= "active";}
else{
$classs= "";	
	
} 

$return_string .= '<div class="tab-pane fade show '. $classs .'" id="nav-' .  $term->slug . '" role="tabpanel" aria-labelledby="nav-' . $term->slug .'-tab">';
$args = array('post_type' => 'restaurant_menu','tax_query' => array( array('taxonomy' => 'menu_categories','field' => 'slug',
    'terms' => $term->slug, ), ),);
	$return_string .= '<div class="row xmt-5">';
	$loop = new WP_Query($args);while($loop->have_posts()) : $loop->the_post();
	$urlimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' );
if ( has_post_thumbnail() ) {
$urlimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' );
} else { 
$urlimg = "https://www.jtopsbbqshop.com/wp-content/uploads/2022/03/JTop_s-logo-greyscale-white.png";
}
    $return_string .= '<div class="col-md-6"><div class="main-card"><div class="card"><div class="dish"><h1>' . get_the_title() . ' </h1></div>
    <div class="description">' . get_the_content() . ' </div><a href="#" class="delvry order-btn">Order Now</a></div><div class="pro-img"><img src="'. $urlimg .'" alt="product" /></div></div></div>';
	endwhile;
		$return_string .= '</div></div>';	
$i++;}; 
	wp_reset_query();
	$return_string .= '</div></div></div></div></section>';
 
  return $return_string;
}
add_shortcode('tab_Shortcode' , 'tabs_shortcode_genrate');